import React, { Component } from 'react'

/* 
沸点下的热门路由组件
*/
export default class Hot extends Component {
  render() {
    return (
      <div>
        沸点==热门
      </div>
    )
  }
}
