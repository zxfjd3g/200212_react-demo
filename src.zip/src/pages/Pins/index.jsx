import React, { Component } from 'react'
/* 
沸点路由组件
*/
export default class Pins extends Component {
  render() {
    return (
      <div>
        沸点
      </div>
    )
  }
}
