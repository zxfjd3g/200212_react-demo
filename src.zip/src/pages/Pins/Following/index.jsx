import React, { Component } from 'react'

/* 
沸点下的关注路由组件
*/
export default class Following extends Component {
  render() {
    return (
      <div>
        沸点==关注
      </div>
    )
  }
}
