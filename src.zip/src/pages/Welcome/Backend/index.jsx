import React, { Component } from 'react'

/* 
首页下的后端路由组件
*/
export default class Backend extends Component {
  render() {
    return (
      <div>
        首页==后端
      </div>
    )
  }
}
