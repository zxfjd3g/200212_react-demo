import React, { Component } from 'react'

/* 
首页下的前端路由组件
*/
export default class Frontend extends Component {
  render() {
    return (
      <div>
        首页==前端
      </div>
    )
  }
}
