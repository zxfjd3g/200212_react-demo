import React, { Component } from 'react'

/* 
首页路由组件
*/
export default class Welcome extends Component {
  render() {
    return (
      <div>
        首页
      </div>
    )
  }
}
