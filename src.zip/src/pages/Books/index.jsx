import React, { Component } from 'react'

/* 
小册 一级路由
*/
export default class Books extends Component {
  render() {
    return (
      <div>
        小册
      </div>
    )
  }
}
