import React, { Component } from 'react'

/* 
小册下的后端路由组件
*/
export default class Backend extends Component {
  render() {
    return (
      <div>
        小册 ====== 后端
      </div>
    )
  }
}
