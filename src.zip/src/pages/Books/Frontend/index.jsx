import React, { Component } from 'react'

/* 
小册下的前端路由组件
*/
export default class Frontend extends Component {
  render() {
    return (
      <div>
        小册 ====== 前端
      </div>
    )
  }
}
