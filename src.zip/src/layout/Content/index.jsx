import React, { Component } from 'react'
/* 
主体内容组件: 路由组件就在其中显示
*/
export default class Content extends Component {
  render() {
    return (
      <div>
        显示匹配的路由组件
      </div>
    )
  }
}
